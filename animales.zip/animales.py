class Animal:
    
    def __init__(self, nombre, sonido):
        self.nombre = nombre
        self.sonido = sonido
